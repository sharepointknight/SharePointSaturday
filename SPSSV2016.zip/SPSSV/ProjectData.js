'use strict';

angular.module('AngularDemo', ['AngularSP']).controller('DemoController', ['$scope', '$rootScope', '$filter', '$http', 'AngularSPREST','$q',
    function ($scope, $rootScope, $filter, $http, $angularSP, $q) {
        var vm = {};

        $scope.VM = vm;
        
        vm.Tasks = [];
        
        vm.CreateProject = function CreateProject()
        {
        	var data =  {
				description: vm.ProjectDesc,
				enterpriseProjectTypeId: '09fa52b4-059b-4527-926e-99f9be96437a',
				id: createGuid(),
				name: vm.ProjectTitle,
				start: '6/11/2016'
			};
			var webUrl = "/sites/pwa";
			$q.when($angularSP.GetUpdatedDigest(webUrl)).then(function () {
				$.ajax({
				  type: "POST",
				  url: "/sites/pwa/_api/projectserver/Projects",
				  data: JSON.stringify(data),
				  headers: {
			                "Accept": "application/json;odata=verbose",
			                "Content-Type": "application/json",
			                "X-RequestDigest": $angularSP.Support.GetCurrentDigestValue(webUrl)
			            }
				}).then(function (data1) {
					vm.projectID = data.id;
					/*var tdata = {
						id: createGuid(),
						name: 'Test',
						duration: '1d'
					};
					$.ajax({
					  type: "POST",
					  url: "/sites/pwa/_api/projectserver/Projects('a0791434-fc2f-e611-80ce-000d3a32f17a')/checkOut()",
					  headers: {
				                "Accept": "application/json;odata=verbose",
				                "Content-Type": "application/json",
				                "X-RequestDigest": $angularSP.Support.GetCurrentDigestValue(webUrl)
				            }
					}).then(function () {

						debugger;
						$.ajax({
						  type: "POST",
						  url: "/sites/pwa/_api/projectserver/Projects('a0791434-fc2f-e611-80ce-000d3a32f17a')/Draft/Tasks",
						  data: JSON.stringify(tdata),
						  headers: {
					                "Accept": "application/json;odata=verbose",
					                "Content-Type": "application/json",
					                "X-RequestDigest": $angularSP.Support.GetCurrentDigestValue(webUrl)
					            }
						});
					});*/
				});
				/*$http({
	                    url: "/sites/pwa/_api/ProjectServer/Projects",
	                    method: "POST",
	                    data: JSON.stringify(data),
	                    transformRequest: [],
	                    headers: {
	                        "Accept": "application/json;odata=verbose",
                        	'Content-Type': 'application/json;odata=verbose',
	                        "X-RequestDigest": $angularSP.Support.GetCurrentDigestValue(webUrl),
	                    }
	                });*/
            });
        }
        function createTasks()
        {
        	$.ajax({
			  type: "POST",
			  url: "/sites/pwa/_api/projectserver/Projects('a0791434-fc2f-e611-80ce-000d3a32f17a')/checkOut()",
			  headers: {
		                "Accept": "application/json;odata=verbose",
		                "Content-Type": "application/json",
		                "X-RequestDigest": $angularSP.Support.GetCurrentDigestValue(webUrl)
		            }
			}).then(function () {
				var tdata = {
						id: createGuid(),
						name: 'Test',
						duration: '1d'
					};
				debugger;
				$.ajax({
				  type: "POST",
				  url: "/sites/pwa/_api/projectserver/Projects('a0791434-fc2f-e611-80ce-000d3a32f17a')/Draft/Tasks",
				  data: JSON.stringify(tdata),
				  headers: {
			                "Accept": "application/json;odata=verbose",
			                "Content-Type": "application/json",
			                "X-RequestDigest": $angularSP.Support.GetCurrentDigestValue(webUrl)
			            }
				});
				
				$.ajax({
				  type: "POST",
				  url: "/sites/pwa/_api/projectserver/Projects('a0791434-fc2f-e611-80ce-000d3a32f17a')/checkIn()",
				  headers: {
			                "Accept": "application/json;odata=verbose",
			                "Content-Type": "application/json",
			                "X-RequestDigest": $angularSP.Support.GetCurrentDigestValue(webUrl)
			            }
				})
			});

        }
        function createGuid()
		{
			//return '1c05caca-9bee-4d8d-bef4-e12fcdd8e6fb';
		    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		        var r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
		        return v.toString(16);
		    });
		}
        
        function Init()
        {
            $angularSP.GetListItems("Tasks").then(function (data) {
				vm.Tasks = data;
			},function (data) {
				console.log("Error Encountered")
			});
        }
        Init();

    }]);