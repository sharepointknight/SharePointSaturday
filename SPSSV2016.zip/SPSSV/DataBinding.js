'use strict';

angular.module('AngularDemo', ['AngularSP']).controller('DemoController', ['$scope', '$rootScope', '$filter', '$http', 'AngularSPREST',
    function ($scope, $rootScope, $filter, $http, $angularSP) {
        var vm = {};

        $scope.VM = vm;

        vm.Title = "";

        vm.Clicked = function Clicked() {
            alert(vm.Title);
        }

    }]);