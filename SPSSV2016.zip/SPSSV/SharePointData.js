'use strict';

angular.module('AngularDemo', ['AngularSP']).controller('DemoController', ['$scope', '$rootScope', '$filter', '$http', 'AngularSPREST',
    function ($scope, $rootScope, $filter, $http, $angularSP) {
        var vm = {};

        $scope.VM = vm;

        vm.Title = "";
        
        vm.Bands = [];
        vm.newBand = { Title: "", Category: "" };

        vm.Clicked = function Clicked() {
            alert(vm.Title);
        }
        
        vm.Save = function Save() {
            var item = {
                Title: vm.newBand.Title,
                Category: vm.newBand.Category,
                ImageUrl: vm.newBand.ImageUrl,
                Description: vm.newBand.Description
            };
            
            $angularSP.CreateListItem("Bands", "", item).then(function (data) {
                vm.Bands.push(data);
            });
        }
        function Init()
        {
            $angularSP.GetListItems("Bands").then(function (data) {
				vm.Bands = data;
			},function (data) {
				console.log("Error Encountered")
			});
        }
        Init();

    }]);