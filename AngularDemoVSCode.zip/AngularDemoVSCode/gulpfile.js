var gulp = require('gulp');
var gutil = require( 'gulp-util' );
var spSync = require( 'gulp-sharepoint-sync' ); //https://github.com/Fabian-Schmidt/gulp-sharepoint-sync
var config = require('./config.json');

var conn = spSync.create({
        site:'https://sharepointknight.sharepoint.com/',
        authenticationMethod: 'ACS',
        auth_clientId: config.client_id,
        auth_clientSecret: config.secret,
        parallel: 5,
        log:      gutil.log,
        logLevel: 2
    });

gulp.task("deploy-all", function (callback){    
    var globs = [
            'src/**'
        ];

    return gulp.src( globs, { base: 'src', buffer: false } )
        .pipe( conn.newerOrDifferentSize( '/Demo/AngularJS' ) ) // only upload newer files
        .pipe( conn.dest( '/Demo/AngularJS' ) );
})
gulp.task("watch",function () {
    var globs = [
            'src/**'
        ];
    gulp.watch(globs, function(event) {
        gulp.src( globs, { base: 'src', buffer: false } )
        .pipe( conn.newerOrDifferentSize( '/Demo/AngularJS' ) ) // only upload newer files
        .pipe( conn.dest( '/Demo/AngularJS' ) );
    })
})