'use strict';

angular.module('AngularDemo', ['AngularSP']).controller('DemoController', ['$scope', '$rootScope', '$filter', '$http', 'AngularSPREST',
    function ($scope, $rootScope, $filter, $http, $angularSP) {
        var vm = {};
        
        $scope.VM = vm;

        vm.Title = "";
        
        vm.Bands = [];
        vm.newBand = { Title: "", Category: "" };

        vm.Clicked = function Clicked() {
            alert(vm.Title);
        }
        
        vm.Save = function Save() {
            var item = {
                Title: vm.newBand.Title,
                Category: vm.newBand.Category,
                ImageUrl: vm.newBand.ImageUrl,
                Description: vm.newBand.Description
            };
            
            var url = "/_api/web/lists/getbytitle('Bands')/items";
            item["__metadata"] = { "type": "SP.Data.BandsListItem" };

            var promise = $http({
                url: url,
                method: "POST",
                data: item,
                headers: {
                    "Accept": "application/json;odata=verbose",
                    'Content-Type': 'application/json;odata=verbose',
                    "X-RequestDigest": $("#__REQUESTDIGEST").val()
                }
            });
            promise.then(function (data) {
                vm.Bands.push(data.data.d);
            });
        }
        function Init()
        {
            var url = "/_api/web/lists/getbytitle('Bands')/items";
            
            var promise = $http({
                url: url,
                method: "GET",
                headers: { "Accept": "application/json; odata=verbose" }
            });

            promise.then(function (data) {
				vm.Bands = data.data.d.results;
			},function (data) {
				console.log("Error Encountered")
			});
        }
        Init();

    }]);